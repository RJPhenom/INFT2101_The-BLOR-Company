DROP TABLE IF EXISTS room CASCADE;

CREATE TABLE room (
    room_id SERIAL PRIMARY KEY,
    room_number INT, 
    room_type VARCHAR(100)
);
    