DROP TABLE IF EXISTS invoice_item CASCADE;

CREATE TABLE invoice_item (
    invoice_num INT,
    sku VARCHAR(12),
	FOREIGN KEY (invoice_num) REFERENCES invoice(invoice_num) ON DELETE CASCADE,
	FOREIGN KEY (sku) REFERENCES billing_sku(sku) ON DELETE CASCADE
);