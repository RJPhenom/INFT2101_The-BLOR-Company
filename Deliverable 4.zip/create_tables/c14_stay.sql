DROP TABLE IF EXISTS stay CASCADE;

CREATE TABLE stay (
    stay_id SERIAL PRIMARY KEY,
    date_admitted DATE DEFAULT CURRENT_DATE, 
    date_discharged DATE DEFAULT NULL,
    patient_id INT,
	FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE
);
    