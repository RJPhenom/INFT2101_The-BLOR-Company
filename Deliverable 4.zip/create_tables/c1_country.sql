DROP TABLE IF EXISTS country CASCADE;

CREATE TABLE country (
    country_code CHAR(2) PRIMARY KEY,
    country_name VARCHAR(100)
);