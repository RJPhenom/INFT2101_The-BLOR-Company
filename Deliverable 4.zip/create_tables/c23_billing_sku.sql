DROP TABLE IF EXISTS billing_sku CASCADE;

CREATE TABLE billing_sku (
    sku VARCHAR(12) PRIMARY KEY,
    cost_centre_id INT,
    description VARCHAR(255),
    cost MONEY,
	FOREIGN KEY (cost_centre_id) REFERENCES cost_centre(cost_centre_id) ON DELETE CASCADE
);