DROP TABLE IF EXISTS province CASCADE;

CREATE TABLE province (
    province_code CHAR(2) PRIMARY KEY,
    province_name VARCHAR(100)
);