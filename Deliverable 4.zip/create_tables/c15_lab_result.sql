DROP TABLE IF EXISTS lab_result CASCADE;

CREATE TABLE lab_result (
    lab_result_id SERIAL PRIMARY KEY,
    physician_id INT, 
    patient_id INT,
	FOREIGN KEY (physician_id) REFERENCES physician(physician_id) ON DELETE CASCADE,
	FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE
);