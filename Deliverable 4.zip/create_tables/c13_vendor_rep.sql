DROP TABLE IF EXISTS vendor_rep CASCADE;

CREATE TABLE vendor_rep (
    person_id INT, 
    vendor_id INT,
	FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE CASCADE,
	FOREIGN KEY (vendor_id) REFERENCES vendor(vendor_id) ON DELETE CASCADE
);