DROP TABLE IF EXISTS vendor CASCADE;

CREATE TABLE vendor (
    vendor_id SERIAL PRIMARY KEY,
    address_id INT, 
    phone_number VARCHAR(15),
    email VARCHAR(100),
	FOREIGN KEY (address_id) REFERENCES address(address_id) ON DELETE CASCADE
);