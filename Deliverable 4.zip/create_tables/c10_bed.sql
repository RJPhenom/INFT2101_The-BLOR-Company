DROP TABLE IF EXISTS bed CASCADE;

CREATE TABLE bed (
    bed_id SERIAL PRIMARY KEY,
    room_id INT, 
    bed CHAR(1),
    extension INT,
	FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE
);
    