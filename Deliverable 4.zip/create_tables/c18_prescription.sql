DROP TABLE IF EXISTS prescription CASCADE;

CREATE TABLE prescription (
    prescription_id SERIAL PRIMARY KEY,
    physician_id INT, 
    patient_id INT,
    sku VARCHAR(12),
    dose VARCHAR(100),
    quantity int,
	FOREIGN KEY (physician_id) REFERENCES physician(physician_id) ON DELETE CASCADE,
	FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE
);