DROP TABLE IF EXISTS treatment CASCADE;

CREATE TABLE treatment (
    treatment_id SERIAL PRIMARY KEY,
    physician_id INT, 
    dateTime DATE,
    patient_id INT,
	FOREIGN KEY (physician_id) REFERENCES physician(physician_id) ON DELETE CASCADE,
	FOREIGN KEY (patient_id) REFERENCES patient(patient_id) ON DELETE CASCADE
);