DROP TABLE IF EXISTS treatment_prescription CASCADE;

CREATE TABLE treatment_prescription (
    treatment_id INT, 
    prescription_id INT,
	FOREIGN KEY (treatment_id) REFERENCES treatment(treatment_id) ON DELETE CASCADE,
	FOREIGN KEY (prescription_id) REFERENCES prescription(prescription_id) ON DELETE CASCADE
);