DROP TABLE IF EXISTS country_province CASCADE;

CREATE TABLE country_province (
    country_code CHAR(2),
    province_code CHAR(2),
	FOREIGN KEY (country_code) REFERENCES country(country_code) ON DELETE CASCADE,
	FOREIGN KEY (province_code) REFERENCES province(province_code) ON DELETE CASCADE
);