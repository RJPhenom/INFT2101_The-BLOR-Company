DROP TABLE IF EXISTS applied_treatment CASCADE;

CREATE TABLE applied_treatment (
    treatment_id INT, 
    appointment_id INT,
	FOREIGN KEY (treatment_id) REFERENCES treatment(treatment_id) ON DELETE CASCADE,
	FOREIGN KEY (appointment_id) REFERENCES appointment(appointment_id) ON DELETE CASCADE
);