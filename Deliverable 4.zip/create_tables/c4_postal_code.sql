DROP TABLE IF EXISTS postal_code CASCADE;

CREATE TABLE postal_code (
    postal_code VARCHAR(10) PRIMARY KEY,
    province_code CHAR(2),
	FOREIGN KEY (province_code) REFERENCES province(province_code) ON DELETE CASCADE
);