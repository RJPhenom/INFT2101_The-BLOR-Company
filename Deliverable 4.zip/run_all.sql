--- RUN SCRIPT SIMILAR TO THIS ON PGADMIN4 PGSQL TOOL ----
-- optionally create a new database called 'hospital' or alike
--
-- Must be forward slashes in the path (didnt work for me otherwise)
-- \cd 'C:/PATH/Project/Deliverable 4'
-- \i 'C:/PATH/Project/Deliverable 4/run_all.sql'

DROP SCHEMA public CASCADE;
CREATE SCHEMA public;

-- These paths are relative to the directory
\i create_tables/c1_country.sql
\i create_tables/c2_province.sql
\i create_tables/c3_country_province.sql
\i create_tables/c4_postal_code.sql
\i create_tables/c5_address.sql
\i create_tables/c6_person.sql
\i create_tables/c7_physician.sql
\i create_tables/c8_staff.sql
\i create_tables/c9_room.sql
\i create_tables/c10_bed.sql
\i create_tables/c11_patient.sql
\i create_tables/c12_vendor.sql
\i create_tables/c13_vendor_rep.sql
\i create_tables/c14_stay.sql
\i create_tables/c15_lab_result.sql
\i create_tables/c16_appointment.sql
\i create_tables/c17_treatment.sql
\i create_tables/c18_prescription.sql
\i create_tables/c19_treatment_prescription.sql
\i create_tables/c20_applied_treatment.sql
\i create_tables/c21_invoice.sql
\i create_tables/c22_cost_centre.sql
\i create_tables/c23_billing_sku.sql
\i create_tables/c24_invoice_item.sql
\i insert_tables/i1_country.sql
\i insert_tables/i2_province.sql
\i insert_tables/i3_country_province.sql
\i insert_tables/i4_postal_code.sql
\i insert_tables/i5_address.sql
\i insert_tables/i6_person.sql
\i insert_tables/i7_physician.sql
\i insert_tables/i8_staff.sql
\i insert_tables/i9_room.sql
\i insert_tables/i10_bed.sql
\i insert_tables/i11_patient.sql
\i insert_tables/i12_vendor.sql
\i insert_tables/i13_vendor_rep.sql
\i insert_tables/i14_stay.sql
\i insert_tables/i15_lab_result.sql
\i insert_tables/i16_appointment.sql
\i insert_tables/i17_treatment.sql
\i insert_tables/i18_prescription.sql
\i insert_tables/i19_treatment_prescription.sql
\i insert_tables/i20_applied_treatment.sql
\i insert_tables/i21_invoice.sql
\i insert_tables/i22_cost_centre.sql
\i insert_tables/i23_billing_sku.sql
\i insert_tables/i24_invoice_item.sql