INSERT INTO vendor_rep (person_id, vendor_id) 
    VALUES
        (1000601, 1),  -- Advanced Mobility
        (1000602, 2),  -- Advanced Mobility Systems
        (1000603, 3),  -- Bartimaeus Rehab
        (1000604, 4),  -- Bayshore Home Health
        (1000605, 5),  -- Bowes Mobility
        (1000606, 6),  -- Canadian Red Cross
        (1000607, 7),  -- Community Care Durham
        (1000608, 8),  -- Community Care Lindsay
        (1000609, 9),  -- Durham Medical
        (1000610, 10), -- Home Depot
        (1000611, 11), -- Home Healthcare Solutions
        (1000612, 12), -- Lakeridge Health ARC
        (1000613, 13), -- McLean’s Home Healthcare
        (1000614, 14), -- Medichair Toronto
        (1000615, 15), -- Motion Ajax
        (1000616, 16), -- Motion Oshawa
        (1000617, 17), -- Ortho Medical
        (1000618, 18), -- Shoppers Drug Mart
        (1000619, 19), -- Shoppers Home Healthcare
        (1000620, 20), -- Silver Cross Whitby
        (1000621, 21), -- Vital Aire Oshawa
        (1000622, 22); -- Wellwise by Shoppers