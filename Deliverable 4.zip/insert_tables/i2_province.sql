INSERT INTO province (province_code, province_name) 
    VALUES
        ('ON', 'Ontario'),
        ('BC', 'British Columbia'),
        ('AB', 'Alberta'),
        ('MB', 'Manitoba'),
        ('QC', 'Quebec'),
        ('NY', 'New York'),
        ('CA', 'California'),
        ('IL', 'Illinois'),
        ('WA', 'Washington'),
        ('TX', 'Texas'),
        ('PA', 'Pennsylvania'),
        ('AZ', 'Arizona');