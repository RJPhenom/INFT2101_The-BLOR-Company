INSERT INTO country (country_code, country_name) 
    VALUES
        ('CA', 'Canada'),
        ('US', 'United States');