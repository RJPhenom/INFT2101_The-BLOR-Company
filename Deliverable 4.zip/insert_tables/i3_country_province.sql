INSERT INTO country_province (country_code, province_code) 
    VALUES
        ('CA', 'ON'),  -- Canada - Ontario
        ('CA', 'BC'),  -- Canada - British Columbia
        ('CA', 'AB'),  -- Canada - Alberta
        ('CA', 'MB'),  -- Canada - Manitoba
        ('CA', 'QC'),  -- Canada - Quebec
        ('US', 'NY'),  -- United States - New York
        ('US', 'CA'),  -- United States - California
        ('US', 'IL'),  -- United States - Illinois
        ('US', 'WA'),  -- United States - Washington
        ('US', 'TX'),  -- United States - Texas
        ('US', 'PA'),  -- United States - Pennsylvania
        ('US', 'AZ');  -- United States - Arizona