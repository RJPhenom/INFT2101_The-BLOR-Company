-- https://en.wikipedia.org/wiki/ISO/IEC_5218
-- Run once
CREATE FUNCTION get_sex(sex smallint)
RETURNS VARCHAR(10) AS $$
    SELECT CASE
        WHEN sex = 0 THEN 'NOT KNOWN'
        WHEN sex = 1 THEN 'M'
        WHEN sex = 2 THEN 'F'
        WHEN sex = 9 THEN 'N/A'
        ELSE 'INVALID'
    END;
$$ LANGUAGE SQL;

-- PATIENT DISPLAY --
SELECT pa.patient_id "PATIENT-NO", 
    CONCAT(pe.first_name, ' ', pe.last_name) "PATIENT-NAME",
    CONCAT(ad.street_num, ' ', ad.street_name) "PATIENT-ADDRESS", 
    CONCAT(ad.city, ', ', pc.province_code, ' ', pc.postal_code) "CITY-PROV-PC",
    pe.phone_number "TELEPHONE", 
    get_sex(pa.sex) "SEX", 
    pa.hcn "HCN",
    CONCAT(be.room_id, be.bed) "LOCATION",
    be.extension "EXTENSION", 
    st.date_admitted "DATE-ADMITTED",
    pa.financial_status "FINANCIAL-STATUS",
    st.date_discharged "DISCHARGE-DATE"
FROM patient pa 
JOIN person pe ON pa.person_id = pe.person_id
JOIN address ad ON pe.address_id = ad.address_id
JOIN postal_code pc ON ad.postal_code = pc.postal_code
JOIN stay st ON pa.patient_id = st.patient_id
JOIN bed be ON pa.bed_id = be.bed_id
ORDER BY pa.patient_id DESC;

-- PHYSICIAN DISPLAY --
SELECT ph.physician_id "PHYSICIAN-NO",
    CONCAT(pe.first_name, ' ', pe.last_name) "PHYSICIAN-NAME",
    pe.phone_number "TELEPHONE",
    ph.specialty "SPECIALTY"
FROM physician ph 
JOIN person pe ON ph.person_id = pe.person_id
ORDER BY ph.physician_id ASC;

-- DAILY REVENUE REPORT
SELECT 
    pa.patient_id "PATIENT-NO",
    CONCAT(pe.first_name, ' ', pe.last_name) "PATIENT-NAME",
    CONCAT(be.room_id, be.bed) "LOCATION",
    pa.financial_status "FIN-SOURCE",
    bs.cost_centre_id "COST-CENTRE",
    bs.sku "ITEM-CODE",
    bs.description "DESCRIPTION",
    bs.cost "CHARGE",
    SUM(bs.cost) "TOTAL"
FROM patient pa
JOIN person pe ON pa.person_id = pa.person_id
JOIN bed be ON pa.bed_id = be.bed_id
JOIN invoice iv ON pa.patient_id = iv.patient_id
JOIN invoice_item ii ON iv.invoice_num = ii.invoice_num
JOIN billing_sku bs ON ii.sku = bs.sku
GROUP BY pa.patient_id, "PATIENT-NAME", "LOCATION", "COST-CENTRE", "ITEM-CODE"
ORDER BY pa.patient_id;